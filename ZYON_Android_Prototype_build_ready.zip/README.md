# ZYON Android Prototype

Protótipo Android de menu flutuante arrastável, com abas ESP, Aim, Loot, Visual e Config.
Os controles são demonstrativos e persistem em SharedPreferences. Não há integração
com Arena Breakout, captura de memória, detecção de entidades ou automação de mira.

## Abrir
1. Instale Android Studio com Android SDK 35 e JDK 17.
2. Abra esta pasta como projeto Gradle.
3. Sincronize e execute em Android 8.0+.
4. Toque em "Abrir menu flutuante" e conceda permissão de sobreposição.
5. Retorne ao app e toque novamente em "Abrir menu flutuante".

## Próximos módulos
- Canvas de simulação de alvos e barras de vida.
- Catálogo de loot com itens fictícios e pontuação por slot.
- Exportação/importação JSON e temas.
- Testes instrumentados.

Nota: serviço de overlay iniciado diretamente, indicado para protótipo local.
Em versões recentes do Android, serviços de longa duração e inicialização em
segundo plano exigem tratamento adicional de ciclo de vida.

## Gerar APK com GitHub Actions
Envie o conteúdo do projeto para um repositório GitHub (incluindo `.github/workflows/android-build.yml`).
Em Actions, selecione **Android APK build** e clique em **Run workflow**.
Após sucesso, baixe o artefato `ZYON-Prototype-debug-apk` e extraia `app-debug.apk`.
O build é executado no GitHub, não foi executado neste ambiente.
